# checkin.py
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import requests
import logging

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("CheckIn")

app = FastAPI(title="Check-in Module")

# URL Ticket Sales (предположим, что он работает на порту 8002)
TICKET_SALES_URL = "http://localhost:8002"

# Pydantic-модель для запроса регистрации
class CheckInRequest(BaseModel):
    passenger_id: str
    flight_id: str
    food_preference: str = Field(..., description="Например: стандартное, вегетарианское, халяль, без аллергенов и т.д.")
    ticket_class: str = Field(..., description="economy или first")
    baggage_info: dict = Field(default_factory=dict, description="Информация о багаже: вес, количество")

# In-memory база для хранения регистрационных данных
checkin_db = {}

@app.post("/v1/checkin", response_model=dict)
def register_passenger(request: CheckInRequest):
    """
    Обрабатывает регистрацию пассажира.
    1. Проверяет, что пассажир ранее получил билет (обращение к Ticket Sales API).
    2. Если билет получен и время регистрации допустимо (здесь симулируется как всегда допустимо),
       фиксирует регистрацию, сохраняет выбранные опции и информацию о багаже.
    3. Возвращает обновлённое состояние пассажира.
    """
    # Проверка наличия билета: обращаемся к Ticket Sales
    try:
        ts_response = requests.get(f"{TICKET_SALES_URL}/v1/tickets/status/{request.passenger_id}", timeout=2)
        if ts_response.status_code != 200:
            raise HTTPException(status_code=400, detail="Покупка билета не подтверждена")
        ts_data = ts_response.json()
        if ts_data.get("result") != "GotTicket":
            raise HTTPException(status_code=400, detail="Билет не получен или покупка отклонена")
    except Exception as e:
        logger.error(f"Ошибка проверки билета: {e}")
        raise HTTPException(status_code=500, detail="Ошибка при проверке билета")

    # Здесь можно добавить проверку времени регистрации через Information Panel
    # Для демонстрации считаем, что регистрация допустима

    # Фиксируем регистрацию
    checkin_db[request.passenger_id] = {
        "flight_id": request.flight_id,
        "food_preference": request.food_preference,
        "ticket_class": request.ticket_class,
        "baggage_info": request.baggage_info,
        "state": "Registered"
    }
    logger.info(f"Пассажир {request.passenger_id} зарегистрирован с данными: {checkin_db[request.passenger_id]}")
    return {"passenger_id": request.passenger_id, "result": "Registered", "details": checkin_db[request.passenger_id]}

@app.get("/v1/checkin/status/{passenger_id}", response_model=dict)
def get_checkin_status(passenger_id: str):
    """
    Возвращает статус регистрации для указанного пассажира.
    """
    data = checkin_db.get(passenger_id)
    if not data:
        raise HTTPException(status_code=404, detail="Регистрация для данного пассажира не найдена")
    return {"passenger_id": passenger_id, "result": data["state"], "details": data}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("checkin:app", host="0.0.0.0", port=8004, reload=True)
