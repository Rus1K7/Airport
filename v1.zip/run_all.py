import subprocess

services = [
    ("passenger_generator", "8001"),
    ("ticket_sales", "8002"),
    ("information_panel", "8003"),
    ("checkin", "8004"),
]

processes = []

try:
    for module, port in services:
        cmd = ["uvicorn", f"{module}:app", "--host", "0.0.0.0", "--port", port, "--reload"]
        p = subprocess.Popen(cmd)
        processes.append(p)
        print(f"Запущен {module} на порту {port}")

    for p in processes:
        p.wait()

except KeyboardInterrupt:
    for p in processes:
        p.terminate()
