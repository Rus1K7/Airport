# ticket_sales.py
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import pika
import json
import threading
import time
import uuid
import random
import logging

import requests  # для обращения к Information Panel

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("TicketSales")

app = FastAPI(title="Ticket Sales Module")

# Конфигурация RabbitMQ
RABBITMQ_HOST = "localhost"
TICKETS_REQUEST_QUEUE = "TicketsRequest"
TICKETS_RESPONSE_QUEUE = "TicketsResponse"

# URL Information Panel (предположим, что он запущен на порту 8003)
INFO_PANEL_URL = "http://localhost:8003"

# In-memory база для статусов билетов: ключ – passenger_id, значение – состояние
ticket_db = {}


# Pydantic-модель запроса (если используется REST)
class TicketRequest(BaseModel):
    passenger_id: str
    flight_id: str
    action: str  # "buy_ticket" или "return_ticket"


def process_ticket_request(message: dict):
    """
    Обработка запроса на покупку билета.
    Обращается к Information Panel для проверки рейса и свободных мест.
    Решает случайно (или по правилу) выдавать билет.
    """
    try:
        passenger_id = message["passenger_id"]
        flight_id = message["flight_id"]
        action = message.get("action", "buy_ticket")
        logger.info(f"Обработка запроса: passenger_id={passenger_id}, flight_id={flight_id}, action={action}")

        # Здесь можно обратиться к Information Panel для проверки рейса:
        # Пример: GET /flights/{flight_id}
        try:
            response = requests.get(f"{INFO_PANEL_URL}/flights/{flight_id}", timeout=2)
            if response.status_code != 200:
                logger.error("Рейс не найден в Information Panel")
                ticket_db[passenger_id] = "Rejected"
                return
            flight = response.json()
            remaining = flight.get("remaining_seats", 0)
        except Exception as e:
            logger.error(f"Ошибка запроса к Information Panel: {e}")
            ticket_db[passenger_id] = "Rejected"
            return

        # Простейшая логика: если осталось больше 0 мест, выдаём билет; иначе – отказ.
        if remaining > 0:
            # Дополнительно можно уменьшить remaining_seats через вызов Information Panel.
            ticket_db[passenger_id] = "GotTicket"
            logger.info(f"Пассажиру {passenger_id} выдан билет (GotTicket)")
        else:
            ticket_db[passenger_id] = "Rejected"
            logger.info(f"Пассажиру {passenger_id} отказано в покупке билета (Rejected)")

        # Отправка ответа в очередь TicketsResponse (опционально)
        response_message = {
            "passenger_id": passenger_id,
            "action": action,
            "result": ticket_db[passenger_id]
        }
        send_to_rabbitmq_response(response_message)
    except Exception as e:
        logger.error(f"Ошибка в process_ticket_request: {e}")


def send_to_rabbitmq_response(message: dict):
    """Отправка ответного сообщения в очередь TicketsResponse."""
    try:
        connection = pika.BlockingConnection(pika.ConnectionParameters(host=RABBITMQ_HOST))
        channel = connection.channel()
        channel.queue_declare(queue=TICKETS_RESPONSE_QUEUE, durable=True)
        channel.basic_publish(
            exchange='',
            routing_key=TICKETS_RESPONSE_QUEUE,
            body=json.dumps(message),
            properties=pika.BasicProperties(delivery_mode=2)
        )
        connection.close()
        logger.info(f"Отправлен ответ: {message}")
    except Exception as e:
        logger.error(f"Ошибка отправки ответа в RabbitMQ: {e}")


def rabbitmq_consumer():
    """Функция-потребитель для очереди TicketsRequest."""
    while True:
        try:
            connection = pika.BlockingConnection(pika.ConnectionParameters(host=RABBITMQ_HOST))
            channel = connection.channel()
            channel.queue_declare(queue=TICKETS_REQUEST_QUEUE, durable=True)
            channel.basic_qos(prefetch_count=1)
            channel.basic_consume(queue=TICKETS_REQUEST_QUEUE, on_message_callback=callback)
            logger.info("Запущен потребитель RabbitMQ в Ticket Sales")
            channel.start_consuming()
        except Exception as e:
            logger.error(f"Ошибка в rabbitmq_consumer: {e}")
            time.sleep(5)


def callback(ch, method, properties, body):
    try:
        message = json.loads(body.decode())
        process_ticket_request(message)
        ch.basic_ack(delivery_tag=method.delivery_tag)
    except Exception as e:
        logger.error(f"Ошибка в callback: {e}")
        ch.basic_nack(delivery_tag=method.delivery_tag)


# Запуск потребителя в отдельном потоке
threading.Thread(target=rabbitmq_consumer, daemon=True).start()


# Дополнительные REST‑эндпоинты для синхронного запроса (на случай тестирования)
@app.post("/v1/tickets/buy", response_model=dict)
def buy_ticket(request: TicketRequest):
    process_ticket_request(request.dict())
    return {"passenger_id": request.passenger_id, "result": ticket_db.get(request.passenger_id, "Unknown")}


@app.post("/v1/tickets/return", response_model=dict)
def return_ticket(request: TicketRequest):
    # Логика возврата: вернуть билет и увеличить количество мест (через Information Panel)
    ticket_db[request.passenger_id] = "Returned"
    return {"passenger_id": request.passenger_id, "result": "Returned"}


@app.get("/v1/tickets/status/{passenger_id}", response_model=dict)
def get_ticket_status(passenger_id: str):
    status = ticket_db.get(passenger_id)
    if status is None:
        raise HTTPException(status_code=404, detail="Пассажир не найден")
    return {"passenger_id": passenger_id, "result": status}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("ticket_sales:app", host="0.0.0.0", port=8002, reload=True)
