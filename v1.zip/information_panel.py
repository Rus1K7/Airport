# information_panel.py
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional, List
import uuid
import logging
from datetime import datetime, timedelta

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("InformationPanel")

app = FastAPI(title="Information Panel Module")

# Pydantic-модель для рейса
class Flight(BaseModel):
    id: str
    linked_id: Optional[str] = None
    type: str  # "arrive" или "departure"
    status: str  # "Ожидание", "Регистрация", "Посадка", "Вылет", "Отменен", и т.д.
    registration_start: datetime
    departure_time: datetime
    airplane_capacity: int
    remaining_seats: int

# In-memory база рейсов
flights_db = {}

def create_demo_flight(flight_type: str) -> Flight:
    flight_id = str(uuid.uuid4())
    now = datetime.now()
    registration_start = now + timedelta(minutes=5)
    departure_time = now + timedelta(minutes=20)
    capacity = random_capacity = random.randint(100, 150)
    return Flight(
        id=flight_id,
        linked_id=None,
        type=flight_type,
        status="Ожидание",
        registration_start=registration_start,
        departure_time=departure_time,
        airplane_capacity=random_capacity,
        remaining_seats=random_capacity
    )

# Инициализация базы несколькими демонстрационными рейсами
import random
for _ in range(3):
    flight = create_demo_flight("arrive")
    flights_db[flight.id] = flight
    flight = create_demo_flight("departure")
    flights_db[flight.id] = flight

@app.get("/flights", response_model=List[Flight])
def get_all_flights():
    """Возвращает список всех рейсов."""
    return list(flights_db.values())

@app.get("/flights/{flight_id}", response_model=Flight)
def get_flight(flight_id: str):
    flight = flights_db.get(flight_id)
    if not flight:
        raise HTTPException(status_code=404, detail="Рейс не найден")
    return flight

@app.get("/api/v1/flights/arrive", response_model=List[Flight])
def get_arrival_flights():
    """Возвращает список рейсов типа 'arrive'."""
    return [f for f in flights_db.values() if f.type == "arrive"]

@app.get("/api/v1/flights/departure", response_model=List[Flight])
def get_departure_flights():
    """Возвращает список рейсов типа 'departure'."""
    return [f for f in flights_db.values() if f.type == "departure"]

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("information_panel:app", host="0.0.0.0", port=8003, reload=True)
