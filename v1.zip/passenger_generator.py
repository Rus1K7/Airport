from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uuid
import random
import pika
import json
import threading
import logging
import argparse
import uvicorn


# --- Настройка логирования ---
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# --- Конфигурация RabbitMQ ---
RABBITMQ_HOST = "localhost"
TICKETS_REQUEST_QUEUE = "TicketsRequest"

# --- Определение Pydantic-модели для пассажира ---
class Passenger(BaseModel):
    id: str
    name: str
    has_baggage: bool
    state: str
    flight_id: str

    class Config:
        orm_mode = True

# Возможные состояния пассажира
class PassengerState:
    CAME_TO_AIRPORT = "CameToAirport"
    REQUESTED_TICKET = "RequestedTicket"
    GOT_TICKET = "GotTicket"
    REJECTED = "Rejected"

# --- Инициализация FastAPI-приложения ---
app = FastAPI(title="Passenger Generator Module")

# In-memory база для хранения пассажиров
passengers_db = {}

# --- Оптимизированное соединение с RabbitMQ ---
rabbit_connection = None
rabbit_channel = None

def setup_rabbitmq():
    """Инициализирует соединение с RabbitMQ и создает очередь."""
    global rabbit_connection, rabbit_channel
    try:
        rabbit_connection = pika.BlockingConnection(pika.ConnectionParameters(host=RABBITMQ_HOST))
        rabbit_channel = rabbit_connection.channel()
        rabbit_channel.queue_declare(queue=TICKETS_REQUEST_QUEUE, durable=True)
        logger.info("Успешное подключение к RabbitMQ.")
    except Exception as e:
        logger.error(f"Ошибка подключения к RabbitMQ: {e}")

# Вызываем настройку RabbitMQ при старте
setup_rabbitmq()

def send_to_rabbitmq(message: dict):
    """Отправляет сообщение в очередь RabbitMQ."""
    global rabbit_channel, rabbit_connection
    if not rabbit_channel or rabbit_channel.is_closed:
        setup_rabbitmq()

    try:
        rabbit_channel.basic_publish(
            exchange='',
            routing_key=TICKETS_REQUEST_QUEUE,
            body=json.dumps(message),
            properties=pika.BasicProperties(
                delivery_mode=2,  # сообщение сохраняется на диске
            )
        )
        logger.info(f"Отправлено сообщение в RabbitMQ: {message}")
    except Exception as e:
        logger.error(f"Ошибка отправки сообщения в RabbitMQ: {e}")

def get_random_name() -> str:
    names = ["Alice", "Bob", "Charlie", "Diana", "Ethan", "Fiona", "George", "Hannah"]
    return random.choice(names)

def generate_passenger_instance(flight_id: str) -> Passenger:
    """Создает экземпляр пассажира, сохраняет его и отправляет запрос на покупку билета."""
    passenger_id = str(uuid.uuid4())
    passenger = Passenger(
        id=passenger_id,
        name=get_random_name(),
        has_baggage=random.random() < 0.85,
        state=PassengerState.CAME_TO_AIRPORT,
        flight_id=flight_id
    )
    passengers_db[passenger_id] = passenger
    logger.info(f"Сгенерирован пассажир: {passenger}")

    # Формируем сообщение для запроса покупки билета
    message = {
        "passenger_id": passenger.id,
        "flight_id": passenger.flight_id,
        "action": "buy_ticket"
    }
    threading.Thread(target=send_to_rabbitmq, args=(message,), daemon=True).start()

    return passenger

@app.post("/generate_passenger", response_model=Passenger)
def generate_passenger(flight_id: str):
    """Генерирует нового пассажира с заданным flight_id."""
    if not flight_id:
        raise HTTPException(status_code=400, detail="flight_id должен быть указан")
    return generate_passenger_instance(flight_id)

@app.get("/passengers", response_model=list[Passenger])
def get_passengers():
    """Возвращает список всех сгенерированных пассажиров."""
    return list(passengers_db.values())


# --- CLI-режим: генерация пассажиров из консоли ---
def run_cli_mode(num: int, flight_id: str):
    print(f"Генерация {num} пассажиров для рейса {flight_id}:")
    for i in range(num):
        passenger = generate_passenger_instance(flight_id)
        print(f"{i+1}: {passenger.json()}")  # Исправлено: используем .json() для правильного вывода в CLI

# --- Основной блок: выбор режима запуска ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Passenger Generator Module - Запуск в режиме сервера или CLI генерации"
    )
    subparsers = parser.add_subparsers(dest="mode", required=True, help="Режим работы: 'server' или 'cli'")

    # Подпарсер для режима сервера
    server_parser = subparsers.add_parser("server", help="Запуск FastAPI-сервера")
    server_parser.add_argument("--host", type=str, default="0.0.0.0", help="Хост сервера")
    server_parser.add_argument("--port", type=int, default=8001, help="Порт сервера")

    # Подпарсер для CLI-режима
    cli_parser = subparsers.add_parser("cli", help="Генерация пассажиров из консоли")
    cli_parser.add_argument("--num", type=int, required=True, help="Количество пассажиров для генерации")
    cli_parser.add_argument("--flight_id", type=str, required=True, help="ID рейса для пассажиров")

    args = parser.parse_args()

    if args.mode == "server":
        # Запускаем FastAPI-сервер через uvicorn
        uvicorn.run("passenger_generator:app", host=args.host, port=args.port, reload=True)
    elif args.mode == "cli":
        # Запускаем генерацию пассажиров в консольном режиме
        run_cli_mode(args.num, args.flight_id)
