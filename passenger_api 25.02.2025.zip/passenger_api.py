import uvicorn
import requests
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional
import random
import logging

# Логирование
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("PassengerAPI")

app = FastAPI(title="Passenger Module")

# --- Модель пассажира ---
class Passenger(BaseModel):
    guid: str
    name: str
    flight_id: Optional[str] = None  # Выбранный рейс
    baggage_weight: int
    meal_type: str
    state: str = "LookingForFlight"
    vip: bool = False

# --- База пассажиров (in-memory) ---
passengers_db = {}

# Табло API URL
TABLO_API_URL = "http://localhost:8003/v1/flights"

# --- Генерация пассажира ---
@app.post("/v1/passengers/generate")
def generate_passenger(name: str, baggage_weight: int, meal_type: str, vip: bool = False):
    guid = str(random.randint(100000, 999999))  # Простая генерация ID
    passenger = Passenger(guid=guid, name=name, baggage_weight=baggage_weight, meal_type=meal_type, vip=vip)
    passengers_db[guid] = passenger
    return {"message": "Passenger generated", "passenger": passenger}

# --- Выбор рейса пассажиром ---
@app.post("/v1/passengers/{guid}/choose_flight")
def choose_flight(guid: str, preferred_destination: Optional[str] = None, preferred_departure_time: Optional[str] = None):
    # Проверяем, существует ли пассажир
    if guid not in passengers_db:
        raise HTTPException(status_code=404, detail="Passenger not found")

    passenger = passengers_db[guid]

    # Запрашиваем список доступных рейсов с Табло
    try:
        response = requests.get(TABLO_API_URL)
        flights = response.json()
    except requests.RequestException as e:
        logger.error(f"Ошибка получения рейсов: {e}")
        raise HTTPException(status_code=500, detail="Ошибка связи с Табло")

    # Фильтруем рейсы по предпочтениям (если заданы)
    filtered_flights = flights
    if preferred_destination:
        filtered_flights = [f for f in filtered_flights if f["toCity"] == preferred_destination]

    if preferred_departure_time:
        filtered_flights = [f for f in filtered_flights if f["scheduledTime"].split("T")[1][:5] == preferred_departure_time]

    # Если рейсов нет, выдаем ошибку
    if not filtered_flights:
        raise HTTPException(status_code=404, detail="No suitable flights found")

    # Выбираем случайный рейс из доступных
    chosen_flight = random.choice(filtered_flights)

    # Обновляем данные пассажира
    passenger.flight_id = chosen_flight["flightId"]
    passenger.state = "FlightChosen"

    return {
        "guid": passenger.guid,
        "name": passenger.name,
        "chosen_flight": passenger.flight_id,
        "from": chosen_flight["fromCity"],
        "to": chosen_flight["toCity"],
        "scheduled_time": chosen_flight["scheduledTime"]
    }

# --- Получение информации о пассажире ---
@app.get("/v1/passengers/{guid}")
def get_passenger_info(guid: str):
    if guid not in passengers_db:
        raise HTTPException(status_code=404, detail="Passenger not found")
    return passengers_db[guid]


if __name__ == "__main__":
    uvicorn.run("passenger_api:app", host="0.0.0.0", port=8004, reload=True)
