from datetime import datetime
from pydantic import BaseModel
from typing import Optional

class FlightData(BaseModel):
    flightId: str
    planeId: Optional[str] = None
    type: str  # "arrive" или "depart"
    fromCity: Optional[str] = None
    toCity: Optional[str] = None
    scheduledTime: datetime
    arrivalTime: Optional[datetime] = None
    status: str = "Scheduled"
    gate: Optional[str] = None
    planeParking: Optional[str] = None
    runway: Optional[str] = None

def load_demo_flights():
    """
    Возвращает словарь предопределённых рейсов.
    Допустим, все рейсы заданы на 15.03.2025.
    """
    demo_flights = [
        FlightData(
            flightId="FL123",
            planeId="PL001",
            type="depart",
            fromCity="Moscow",
            toCity="Paris",
            scheduledTime=datetime(2025, 3, 15, 9, 0),  # Вылет в 09:00
            arrivalTime=None,
            status="Scheduled",
            gate=None,
            planeParking=None,
            runway=None
        ),
        FlightData(
            flightId="FL999",
            planeId="PL777",
            type="arrive",
            fromCity="Berlin",
            toCity="Moscow",
            scheduledTime=datetime(2025, 3, 15, 10, 30),  # Прилёт в 10:30
            arrivalTime=None,
            status="Scheduled",
            gate="G1",
            planeParking=None,
            runway="R2"
        ),
        FlightData(
            flightId="FL456",
            planeId="PL002",
            type="depart",
            fromCity="Moscow",
            toCity="London",
            scheduledTime=datetime(2025, 3, 15, 19, 0),  # Вылет в 19:00
            arrivalTime=None,
            status="Scheduled",
            gate=None,
            planeParking=None,
            runway=None
        ),
        FlightData(
            flightId="FL789",
            planeId="PL003",
            type="depart",
            fromCity="Moscow",
            toCity="Prague",
            scheduledTime=datetime(2025, 3, 15, 21, 0),  # Вылет в 21:00
            arrivalTime=None,
            status="Scheduled",
            gate=None,
            planeParking=None,
            runway=None
        ),
        FlightData(
            flightId="FL555",
            planeId="PL004",
            type="depart",
            fromCity="Moscow",
            toCity="Nice",
            scheduledTime=datetime(2025, 3, 15, 23, 0),  # Вылет в 23:00
            arrivalTime=None,
            status="Scheduled",
            gate=None,
            planeParking=None,
            runway=None
        )
    ]
    return {flight.flightId: flight for flight in demo_flights}

# Глобальная переменная для базы рейсов
flights_db = load_demo_flights()
